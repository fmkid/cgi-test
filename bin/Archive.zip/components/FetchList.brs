sub init()
    m.top.response = GetDataFromLists()
end sub

function GetDataFromLists() as Object
    m.port = CreateObject("roMessagePort")
    m.urlXfer = CreateObject("roUrlTransfer")
    respList = CreateObject("roArray", 0, true)

    token = fetchJson(m.top.tokenUrl)
    response = fetchJson(m.top.urlList)
    if type(response) = "roArray" and response.Count() > 0
        for each item in response
            if token.DoesExist("sessionToken") then item.token = token.sessionToken
             respList.push(item)
        end for
    end if
    return respList
 end function

function fetchJson(url as String) as Object
    m.urlXfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    m.urlXfer.InitClientCertificates()
    m.urlXfer.SetPort(m.port)

    if m.urlXfer = invalid or not m.urlXfer.SetUrl(url) or not m.urlXfer.AsyncGetToString()
        ? "[FetchData] Error al iniciar conexión"
        return {}
    end if

    while true
        msg = wait(0, m.port)
        if type(msg) = "roUrlEvent"
            if msg.GetResponseCode() = 200
                return ParseJson(msg.GetString())
            else
                ? "[FetchData] HTTP "; msg.GetResponseCode()
            end if
            exit while
        end if
    end while
    return {}
end function
