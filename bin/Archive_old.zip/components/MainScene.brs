' Inicializa los elementos de la escena y configura eventos
sub Init()
    sleep(1500)

    ' Configurar elementos de UI
    m.video = m.top.findNode("Video")

    ' Cargar lista de videos y reproducir último ítem guardado
    m.count = 2200
    LoadVideoData(LoadIndexFromRegistry())
end sub

' Carga y valida los datos de video desde FetchData
sub LoadVideoData(index as Integer)
    m.index = index
    fetcher = CreateObject("roSGNode", "FetchData")
    fetcher.url = "https://api.pluto.tv/v2/channels/" + index.ToStr()
    fetcher.trigger = true
    response = ParseJson(fetcher.response)
    video = validateResp(response)
    m.error = video.DoesExist("error")
    
    if not m.error
        SaveIndexToRegistry(index)
        m.video.content = CreateObject("roSGNode", "ContentNode")
        m.video.content.title = (index + 1).toStr() + ". " + video.name
        m.video.content.secondaryTitle = video.summary
        m.video.content.url = m.top.plutoPrefix + video._id + m.top.plutoSuffix
        m.video.setFocus(true)
        m.video.control = "play"     
    end if
end sub

' Valida que la respuesta del servidor contenga contenido válido
function validateResp(resp as Object) as Object
    if resp <> invalid and type(resp) = "roAssociativeArray" and resp.DoesExist("name") and resp.DoesExist("_id") and resp.name <> "" then return resp
    return {error: true}
end function

' Guarda el índice actual en el registro
sub SaveIndexToRegistry(index as Integer)
    section = CreateObject("roRegistrySection", "cache")
    section.Write("stored_index", index.ToStr())
    section.Flush()
end sub

' Carga el índice guardado desde el registro
function LoadIndexFromRegistry() as Integer
    section = CreateObject("roRegistrySection", "cache")
    data = section.Read("stored_index")
    if data <> invalid and data.Len() > 0
        index = StrToI(data)
        if index < m.count then return index
    end if
    return 0
end function

' Maneja eventos del control remoto
sub onKeyEvent(key as String, press as Boolean) as Boolean
    if press and m.count > 1
        if key = "up" or key = "down"
            while true
                LoadVideoData(changeIndex(key))
                if not m.error then exit while
            end while
            return true
        end if
    end if
    return false
end sub

' Cambia el índice actual del video (navegación)
function changeIndex(key as String) as Integer
    if key = "up" then return (m.count + m.index - 1) mod m.count
    if key = "down" then return (m.count + m.index + 1) mod m.count
end function
