sub init()
    m.port = CreateObject("roMessagePort")
    m.urlXfer = CreateObject("roUrlTransfer")
    m.urlXfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    m.urlXfer.InitClientCertificates()
    m.urlXfer.SetPort(m.port)
    m.top.observeField("trigger", "fetchJson") 
end sub

sub fetchJson()
    if m.urlXfer = invalid or not m.urlXfer.SetUrl(m.top.url) or not m.urlXfer.AsyncGetToString()
        ? "[FetchData] Error al iniciar conexión"
        return
    end if

    while true
        msg = wait(0, m.port)
        if type(msg) = "roUrlEvent"
            if msg.GetResponseCode() = 200
                m.top.response = msg.GetString()
            else
                ? "[FetchData] HTTP "; msg.GetResponseCode()
            end if
            exit while
        end if
    end while
end sub
